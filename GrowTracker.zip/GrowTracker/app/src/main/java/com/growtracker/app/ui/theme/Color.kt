package com.growtracker.app.ui.theme

import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF141414)
val BgGlow = Color(0x2EB4F000)
val Surface = Color(0xFF1E1E1E)
val Surface2 = Color(0xFF262626)
val Stroke = Color(0xFF333333)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF8C8C8C)
val Lime = Color(0xFFB4F000)
val OnLime = Color(0xFF141414)
val Green = Color(0xFF7ED957)
val Yellow = Color(0xFFF7C948)
val Purple = Color(0xFF8B7BF7)
val Red = Color(0xFFFF5A5A)