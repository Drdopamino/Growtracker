package com.growtracker.app.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.growtracker.app.ui.theme.Lime

@Composable
fun CalendarScreen() {
    Box(Modifier.fillMaxSize().padding(20.dp), contentAlignment = Alignment.TopStart) {
        Text("КАЛЕНДАРЬ", style = MaterialTheme.typography.displayLarge, color = Lime)
    }
}