package com.growtracker.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.growtracker.app.ui.theme.Stroke
import com.growtracker.app.ui.theme.Surface

@Composable
fun GrowCard(
    modifier: Modifier = Modifier,
    backgroundColor: Color = Surface,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .background(backgroundColor, RoundedCornerShape(20.dp))
            .border(1.dp, Stroke, RoundedCornerShape(20.dp))
            .padding(16.dp),
        content = content
    )
}